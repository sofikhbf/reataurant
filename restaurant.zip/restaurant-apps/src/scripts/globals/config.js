const CONFIG = {
    KEY: 'e346aca855600a71da37711e8e035d55',
    BASE_URL: 'https://api.themoviedb.org/3/',
    BASE_IMAGE_URL: 'https://image.tmdb.org/t/p/w500/',
    DEFAULT_LANGUAGE: 'en-us',
    CACHE_NAME: 'MovieCatalogue-V1',
    // CACHE_NAME: new Date().toISOString(),
  };
   
  export default CONFIG;